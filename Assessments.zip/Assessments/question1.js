let inputstring=['ab','ab','abc']
let querystring=['ab','abc','bc',]
let output=[];

for(let i=0;i<=querystring.length-1;i++)
{
    let key=querystring[i]
let counter=0;
    for(let j=0;j<=inputstring.length-1;j++)
    {

        if(key===inputstring[j])
        {
            counter++;
        }


    }

    output.push(counter);

}

console.log(output);